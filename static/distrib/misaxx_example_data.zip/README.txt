MISA++ Glomeruli Analysis example data
--------------------------------------

Published by Klingberg, Anika, et al. "Fully automated evaluation of total glomerular number and capillary tuft size in nephritic kidneys using lightsheet microscopy." 
Journal of the American Society of Nephrology 28.2 (2017): 452-459.

Instructions for MISA++ for ImageJ
--------------------------------------

1. Open MISA++ for ImageJ
2. Select "MISA++ Kidney Glomeruli Segmentation"
3. Click "Launch"
4. Click "Import folder"
5. Load the "input" folder via "Import folders"
6. Remove the unnecessary sample "New sample"
7. Click "Run", then "Run now"

